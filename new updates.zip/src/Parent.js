
import React, {Component} from "react";
import Child from "./Child";
class Parent extends Component{
    state = {
        balance : 0,
    };

    balanceIncrement = () => {
          this.setState({balance: this.state.balance + 1}
          );
         };

    render(){
        const {name} = this.props;
        return( 
            <>
        
          <h1> 
             Profit of Family  {this.state.balance}
              </h1> 
            <button onClick ={this.balanceIncrement} > 
             Family Profit
            </button><h1>First Child profit</h1>
            <Child name = {"Ankur"}  balanceIncrement={this.balanceIncrement} /> 
            <h1>Second Child profit</h1>
      <Child name = {"Avinash"}  balanceIncrement={this.balanceIncrement}/> 
           
        </>
        );
    }
}

export default Parent;