/* export default() => {  
    return <h2>I Am Inside ThirdChild</h2>;
}; */

function ThirdChild(props){
    const { childComponentName } =props;
    return (
    <div>
    <h3> In ThirdChild called from 
         { childComponentName }
          </h3>
        </div>
    );

}
export default ThirdChild;


