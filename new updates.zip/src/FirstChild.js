/* export default() => {  
    return <h2>I Am Inside FirstChild</h2>;
}; */



//=====assignment====//
function FirstChild(props){
    const { childComponentName } =props;
    return (
    <div>
    <h3> In FirstChild called from  { childComponentName }
          </h3>
        
        </div>
    );

}
export default FirstChild;

