/* import React,{Component} from "react";


class MyFirstClassComponent extends Component{
    render(){
        const {name,age}=this.props;

        return <h1>My First Class Component name and age is {name} {age}</h1>
    }
}
export default MyFirstClassComponent; */



//======state and props and events=====//

/* import React,{Component} from "react";


class MyFirstClassComponent extends Component{
    state ={
        balance:0,
    };
    // state ={
    //     account:abcd234,
    // };

    balanceIncrement =(value)=>{
        this.setState({
            balance:this.state.balance+value
        });
    };
    onProfitClickHandler=()=>{
        console.log("i am clicked");
        this.balanceIncrement(1);
    };

    //this.setState({
     //   balance:this.state.balance+1
   // })

   onDoubleProfitClickHandler=()=>{
             this.balanceIncrement(100);
   };
    
     //this.setState({
     //   balance:this.state.balance+1
   // })
   
    render(){
        const {name,age}=this.props;

        return (
            <>
            <h1>My First Class Component name and age is {name},{age} 
             and my balance is {""} {this.state.balance} in account {this.props.accountNumber} </h1>
           <button onClick={this.onProfitClickHandler}>Profit</button>
           <button onClick={this.onDoubleProfitClickHandler}>DoubleProfit</button>
           
        </>
        );
    }
}
export default MyFirstClassComponent; */