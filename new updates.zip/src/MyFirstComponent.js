/* import FirstChild from "./FirstChild";
import SecondChild from "./SecondChild";
import ThirdChild from "./ThirdChild";
function MyFirstComponent(props) {
    return ( 
    <> 
    <h2>I Am Inside MyFirstComponent</h2>;
    <FirstChild/>;
    <SecondChild/>;
    <ThirdChild/>;
    </>
    );
} */

//export default MyFirstComponent;


//======props=====//

/* 
function MyFirstComponent(props) {
    const {name1,age } =props;
    console.log(name1);
    console.log(age);
    return ( 
    <> 
    <h2>I Am {name1},my age {age} yrs old and i m Inside MyFirstComponent</h2>;

    </>
    );
}

export default MyFirstComponent; */



//====children====//
/* function MyFirstComponent(props) {
    console.log(props);
    const {name1,age,children } =props;
    console.log(name1);
    console.log(age);
   
    return ( 
    <> 
    <h2>I Am {name1},my age {age} yrs old and i m Inside MyFirstComponent</h2>;
    {children}
    </>
    );
}

export default MyFirstComponent; */

// assignment ..first child called from myfirstcomponent//
import FirstChild from "./FirstChild";
import SecondChild from "./SecondChild";
import ThirdChild from "./ThirdChild";

function MyFirstComponent(props) {
  const { name, age, children } = props;
  const { parentComponentName } =props;

  console.log(props.name);
  console.log(props.age);
    return (
     <>
      
      <h3>My MyFirstComponent called from { parentComponentName } </h3>
       <FirstChild   childComponentName = {"MyFirstComponent"} />
      <SecondChild  childComponentName = {"MyFirstComponent"}/>
      <ThirdChild childComponentName = {"MyFirstComponent"}/>
      </>
      );
  }
  export default MyFirstComponent;

