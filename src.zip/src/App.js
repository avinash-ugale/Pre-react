// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


/* import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";

function App() {
  const name = "Avinash";
  return (
    <>
  <div>
    <h1>Hello {name && name.length ? name:"world"}</h1>
    <MyFirstComponent />
    <MySecondComponent/>
  </div>
  </>
  );
}

export  default App; */


//======props=====//
/* import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";

function App() {
  const name1 = "Avinash";
  const name2 = "Avi";
  return (
   
  <div>
    <h1>Hello {name1 && name1.length ? name1:"world"}</h1>
    <MyFirstComponent name1={name1} age={25} />
    <MySecondComponent name2={name2} age={29} />
  
  </div>
  
  );
}

export  default App; */

//====children prop=====//

/* import MyFirstComponent from "./MyFirstComponent";


function App() {
  const name1 = "Avinash";

  return (
   
  <div>
    <h1>Hello {name1 && name1.length ? name1:"world"}</h1>
    <MyFirstComponent name1={name1} age={25} ><h2>some data passed into app component</h2>
    </MyFirstComponent>
    <MyFirstComponent parentComponentName ={"App"}/>
  
  </div>
  
  );
}

export  default App; */

// asssignment //
import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";
function App() {
  const name = "Lokesh";
  return (
    <>
      <h1> Hello {name && name.length ? name :"World React"} </h1>
    
   <div><h3>MyFirstComponent</h3></div>

      <MyFirstComponent parentComponentName = {"App"}>
      </MyFirstComponent >

    <div><h3>MySecondComponent</h3></div>

    <MySecondComponent parentComponentName = {"App"}>
    </MySecondComponent > 
    
      
    </>
  );
}
export default App;

      
         
  






