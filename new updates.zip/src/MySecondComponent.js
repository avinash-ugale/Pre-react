//Step1
// function MyFirstComponent() {
//     return <h2>I Am Inside MyFirstComponent</h2>;
// }

// export default MyFirstComponent;

// //Step2
// const MySecondComponent = () => {      //Arrow funtion
//     return <h2>I Am Inside MySecondComponent</h2>;
// }

// export default MySecondComponent;


//Step3
/* import FirstChild from "./FirstChild";
import SecondChild from "./SecondChild";
import ThirdChild from "./ThirdChild";
export default() => {  
    return (<> <h2>I Am Inside MySecondComponent</h2>;
    <FirstChild/>;
    <SecondChild/>;
    <ThirdChild/>;
    </>
    );
}; */


//====props=====//

/* function MySecondComponent(props) {
    const {name,age } =props;
    console.log(name);
    console.log(age);
    return ( 
    <> 
    <h2>I Am {name},my age {age} yrs old and i m Inside MyFirstComponent</h2>;

    </>
    );
}

export default MyFirstComponent; */

// === called first from firstcomponent  //

import FirstChild from "./FirstChild";
import SecondChild from "./SecondChild";
import ThirdChild from "./ThirdChild";

function MySecondComponent(props) {
  const { name, age } = props;
  const { parentComponentName } =props;
  console.log(props.name);
  console.log(props.age);
    return (
    <>
  

    <h3> My MySecondComponent called from { parentComponentName } </h3>
       <FirstChild   childComponentName = {"MySecondComponent"} />
      <SecondChild  childComponentName = {"MySecondComponent"}/>
      <ThirdChild childComponentName = {"MySecondComponent"}/>     
   </>





    );
  }
  export default MySecondComponent;


	
