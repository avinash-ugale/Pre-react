// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


/* import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";

function App() {
  const name = "Avinash";
  return (
    <>
  <div>
    <h1>Hello {name && name.length ? name:"world"}</h1>
    <MyFirstComponent />
    <MySecondComponent/>
  </div>
  </>
  );
}

export  default App; */


//======props=====//
/* import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";

function App() {
  const name1 = "Avinash";
  const name2 = "Avi";
  return (
   
  <div>
    <h1>Hello {name1 && name1.length ? name1:"world"}</h1>
    <MyFirstComponent name1={name1} age={25} />
    <MySecondComponent name2={name2} age={29} />
  
  </div>
  
  );
}

export  default App; */

//====children prop=====//

/* import MyFirstComponent from "./MyFirstComponent";


function App() {
  const name1 = "Avinash";

  return (
   
  <div>
    <h1>Hello {name1 && name1.length ? name1:"world"}</h1>
    <MyFirstComponent name1={name1} age={25} ><h2>some data passed into app component</h2>
    </MyFirstComponent>
    <MyFirstComponent parentComponentName ={"App"}/>
  
  </div>
  
  );
}

export  default App; */

// asssignment //
/* import MyFirstComponent from "./MyFirstComponent";
import MySecondComponent from "./MySecondComponent";
function App() {
  const name = "Avinash";
  return (
    <>
      <h1> Hello {name && name.length ? name :"World React"} </h1>
    
   <div><h3>MyFirstComponent</h3></div>

      <MyFirstComponent parentComponentName = {"App"}>
      </MyFirstComponent >

    <div><h3>MySecondComponent</h3></div>

    <MySecondComponent parentComponentName = {"App"}>
    </MySecondComponent > 
    
      
    </>
  );
}
export default App; */


//*****Saturday 11/10 *//

//===proptypes====//

/* import PropsValidate from "./PropsValidate";
function App() {
  const name="Avinash";
  return (
    <div >
      <PropsValidate name={"Avinash"} age={29}
      renderable={"some string"}
      rollNumber={10}
      remark={"some string"}
      myArr={[1,2,3,4,5]}

      myObject={{
          name:"Avinash",
          age:29,
          mobile:"202939022",
      }}

      
      >
        </PropsValidate>
    </div>
  );
}

export default App; */

//=====render()======//
/* 
 import MyFirstClassComponent from "./MyFirstClassComponent";
  import PropsValidate from "./PropsValidate"
 function App() {
  const name="Avinash"
  return (
    <div>
    <MyFirstClassComponent name={"Avinash"} age={23}/>
    <MyFirstClassComponent name={"Avi"} age={24}/>
    </div>
  );
}

export default App; */ 



//=======state and props=======//

/* 
import MyFirstClassComponent from "./MyFirstClassComponent";
import PropsValidate from "./PropsValidate"
function App() {
const name="Avinash"
return (
  <div>
  <MyFirstClassComponent name={"Avinash"} age={23} accountNumber={"UINB3455"}/>
  
  </div>
);
}

export default App; */


//===two child and parent ===//


import Parent from "./Parent";

function App(){
  const name = "aVI";
  return(
  
    <div>
      
      <Parent/>
      
    </div>
  );
}
export default App;








      
         
  






